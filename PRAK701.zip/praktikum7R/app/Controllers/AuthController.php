<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\UserModel;

class AuthController extends BaseController
{
    public function index()
    {
        return view('login');
    }

    public function login()
    {
        $model = new UserModel();
        $email = request()->getPost('email');
        $password = request()->getPost('password');
        $dataUser = $model->where(["email" => $email])->first();
        if($dataUser){
            if(password_verify($password, $dataUser['password'])){
                session()->set([
                    "email" => $email,
                    "isLoggedIn" => true
                ]);
                return redirect()->to(base_url('/'));
            } else {
                session()->setFlashdata(["pesan" => "email atau password salah"]);
                return redirect()->to(base_url('/login'));
            }
        }else {
            session()->setFlashdata(["pesan" => "email atau password salah"]);
            return redirect()->to(base_url('/login'));
        }
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to(base_url('login'));
    }
}
