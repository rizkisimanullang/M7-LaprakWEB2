<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;
use App\Models\CrudModel;

class CrudSeeder extends Seeder
{
    public function run()
    {
        $model = new CrudModel();
        $model->insert([
            "nama" => "M Rizki Simanullang",
            "nim" => "2110817310003",
            "alamat" => "Banjarmasin"
        ]);
    }
}
